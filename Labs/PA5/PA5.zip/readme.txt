To use:

make clean

make all

./pa5-encfs <password> <mirrordir> <mountdir>